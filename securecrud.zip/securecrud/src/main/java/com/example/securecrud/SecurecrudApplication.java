package com.example.securecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SecurecrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecurecrudApplication.class, args);

    }

}
